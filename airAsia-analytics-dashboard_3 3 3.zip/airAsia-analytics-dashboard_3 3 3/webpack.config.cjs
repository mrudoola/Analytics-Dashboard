module.exports = {
    entry: './node_modules',
    target: 'node',
    output: {
        path: '/Users/apple/Desktop/airAsia-analytics-dashboard_3/public/scripts',
        filename: 'bundleNodeMobules.js',
        libraryTarget: 'var',
        library: 'EntryPoint'
    }
};