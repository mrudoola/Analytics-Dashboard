function newGraph(){
    var M100sCount = sessionStorage.getItem('M100sCount');
    var M200sCount = sessionStorage.getItem('M200sCount');
    var M300sCount = sessionStorage.getItem('M300sCount');
    var M400sCount = sessionStorage.getItem('M400sCount');
    var M500sCount = sessionStorage.getItem('M500sCount');
    var M600sCount = sessionStorage.getItem('M600sCount');
  
    var inScopeQueries = sessionStorage.getItem('inScopeQueries');
    var inScopeQueriesPercent = sessionStorage.getItem('inScopeQueriesPercent');
    var Not_In_Scope_Percent = sessionStorage.getItem('Not_In_Scope_Percent');
    var unassistedAutomation = sessionStorage.getItem('unassistedAutomation');
    var flight_status_percent = sessionStorage.getItem('flight_status_percent');
    var noShowRefundPercent = sessionStorage.getItem('noShowRefundPercent');
    var voluntaryrefundPercent = sessionStorage.getItem('voluntaryrefundPercent');
    var InvoluntaryrefundPercent = sessionStorage.getItem('InvoluntaryrefundPercent');
    var assistedAutomationPercent = sessionStorage.getItem('assistedAutomationPercent');
    var api_failure_percent = sessionStorage.getItem('api_failure_percent');
    var flight_not_found_percent= sessionStorage.getItem('flight_not_found_percent');
    var business_validation_percent = sessionStorage.getItem('business_validation_percent');
    var mobileNotMappedPercent = sessionStorage.getItem('mobileNotMappedPercent');
    var agentRequestedPercent = sessionStorage.getItem('agentRequestedPercent');
    var duringFlowPercent= sessionStorage.getItem('duringFlowPercent');
    var afterFlowPercent = sessionStorage.getItem('afterFlowPercent');
    var userDeclinedPercent = sessionStorage.getItem('userDeclinedPercent');
    var noDeflectionPercent = sessionStorage.getItem('noDeflectionPercent');
  
    var M201Count = sessionStorage.getItem('M201Count');
    var M202Count = sessionStorage.getItem('M202Count');
    var M203Count = sessionStorage.getItem('M203Count');
    var M204Count = sessionStorage.getItem('M204Count');
    var M150andM500sCount = sessionStorage.getItem('M150andM500sCount');
    var M150Count = sessionStorage.getItem('M150Count');
    var M301sCount = sessionStorage.getItem('M301sCount');
    var mobileNoNotMapped = sessionStorage.getItem('mobileNoNotMapped');
    var api_failure_Count = sessionStorage.getItem('api_failure_Count');
    var business_validation_Count = sessionStorage.getItem('business_validation_Count');
      
    var config = {
      container: "#basic-example",
      
      connectors: {
          type: 'step'
      },
      node: {
          HTMLclass: 'nodeExample1'
      }
  },
  Total_Queries = {
      text: {
          name: "Total Queries",
          value: M100sCount
      }
  },
  
  In_Scope_Queries = {
      parent: Total_Queries,
      stackChildren: true,
      text:{
          name: "In Scope Queries",
          value: inScopeQueries +"\t("+inScopeQueriesPercent+"%)"
      }
  },
  Not_In_Scope = {
      parent: Total_Queries,
      stackChildren: true,
      text:{
          name: "Not In Scope",
          value: M100sCount - inScopeQueries +"\t("+Not_In_Scope_Percent+"%)"
      }
  },
  
  Unassisted_Automation = {
      parent: In_Scope_Queries,
      stackChildren: true,
      text:{
          name: "Unassisted Automation", 
          value:M200sCount+"\t("+unassistedAutomation+"%)" 
      }
  },
  Flight_Status = {
      parent: Unassisted_Automation,
      text:{
          name: "Flight Status", 
          value:M201Count+"\t("+flight_status_percent+"%)" 
      }
  },
  No_Show_Refund = {
      parent: Unassisted_Automation,
      text:{
          name: "No Show Refund", 
          value:M202Count+"\t("+noShowRefundPercent+"%)"  
      }
  },
  Voluntary_Refund = {
      parent: Unassisted_Automation,
      text:{
          name: "Voluntary Refund", 
          value:M203Count+"\t("+voluntaryrefundPercent+"%)"   
      }
  },
  Involuntary_Refund = {
      parent: Unassisted_Automation,
      text:{
          name: "Involuntary Refund", 
          value:M204Count+"\t("+InvoluntaryrefundPercent+"%)"  
      }
  },
  
  Assisted_Automation = {
      parent: In_Scope_Queries,
      stackChildren: true,
      text:{
          name: "Assisted Automation",
          value:M300sCount+"\t("+assistedAutomationPercent+"%)"  
      }
  },
  
  API_Failures = {
      parent:Assisted_Automation,
      text:{
          name: " API Failures",
          value:api_failure_Count+"\t("+api_failure_percent+"%)"   
      }
  },
  Flight_Not_Found = {
      parent:Assisted_Automation,
      text:{
          name: " Flight Not Found",
          value:M301sCount+"\t("+flight_not_found_percent+"%)"   
      }
  },
  Business_Validations = {
      parent:Assisted_Automation,
      text:{
          name: " Business Validations",
          value:business_validation_Count+"\t("+business_validation_percent+"%)"  
      }
  },
  Mobile_No_Not_Mapped = {
      parent:Assisted_Automation,
      text:{
          name: "Mobile No Not Mapped",
          value: mobileNoNotMapped+"\t("+mobileNotMappedPercent+"%)"   
      }
  },
  
  Agent_Requested_By_User = {
      parent: In_Scope_Queries,
      stackChildren: true,
      text:{
          name: "Agent Requested By User",
         value:M150andM500sCount+"\t("+agentRequestedPercent+"%)" 
      }
  },
  During_the_Flow = {
      parent: Agent_Requested_By_User,
      stackChildren: true,
      text:{
          name: "During The Flow",
         value:M500sCount+"\t("+duringFlowPercent+"%)"  
      }
  },
  After_the_Flow = {
      parent: Agent_Requested_By_User,
      stackChildren: true,
      text:{
          name: "After The Flow",
          value:M150Count+"\t("+afterFlowPercent+"%)" 
      }
  },
  User_Declined_Confirmation = {
      parent: In_Scope_Queries,
      text:{
          name: "User Declined Confirmation",
          value:M600sCount+"\t("+userDeclinedPercent+"%)"  
      }
  },
  No_Deflection = {
      parent: In_Scope_Queries,
      stackChildren: true,
      text:{
          name: "No Deflection",
          value:M400sCount+"\t("+noDeflectionPercent+"%)"    
      }
  }
  let chart_config = [
      config,
      Total_Queries,
      In_Scope_Queries,
      Not_In_Scope,
      Unassisted_Automation,
      Flight_Status,
      No_Show_Refund,
      Voluntary_Refund,
      Involuntary_Refund,
      Assisted_Automation,
      API_Failures,
      Flight_Not_Found,
      Business_Validations,
      Mobile_No_Not_Mapped,
      Agent_Requested_By_User,
      During_the_Flow,
      After_the_Flow,
      User_Declined_Confirmation,
      No_Deflection
  ];
  
  new Treant( chart_config );
}