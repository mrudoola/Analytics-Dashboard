function downloadData() {
    totalQueries = sessionStorage.getItem("totalQueries");
    totalCallsIntent = sessionStorage.getItem("totalCallsIntent");
    flight_status = sessionStorage.getItem("flight_status");
    refundTagsCount = sessionStorage.getItem("refundTagsCount");
    M100sCount = sessionStorage.getItem('M100sCount');
    M200sCount = sessionStorage.getItem('M200sCount');
    M300sCount = sessionStorage.getItem('M300sCount');
    M400sCount = sessionStorage.getItem('M400sCount');
    M500sCount = sessionStorage.getItem('M500sCount');
    M600sCount = sessionStorage.getItem('M600sCount');

    newQueries_dates = JSON.parse(sessionStorage.getItem("newQueries_dates"));
     M101Tags = JSON.parse(sessionStorage.getItem("M101Tags"));
     M201Tags = JSON.parse(sessionStorage.getItem("M201Tags"));
     sampleArray2 = JSON.parse(sessionStorage.getItem("sampleArray2"));
     sampleArray4 = JSON.parse(sessionStorage.getItem("sampleArray4"));

    inScopeQueries = sessionStorage.getItem('inScopeQueries');
    M201Count = sessionStorage.getItem('M201Count');
    M202Count = sessionStorage.getItem('M202Count');
    M203Count = sessionStorage.getItem('M203Count');
    M204Count = sessionStorage.getItem('M204Count');
    M150andM500sCount = sessionStorage.getItem('M150andM500sCount');
    M150Count = sessionStorage.getItem('M150Count');
    M301sCount = sessionStorage.getItem('M301sCount');
    mobileNoNotMapped = sessionStorage.getItem('mobileNoNotMapped');
    api_failure_Count = sessionStorage.getItem('api_failure_Count');
    business_validation_Count = sessionStorage.getItem('business_validation_Count');

   M200Tags = JSON.parse(sessionStorage.getItem("M200Tags"));
   M300Tags = JSON.parse(sessionStorage.getItem("M300Tags"));
   M400Tags = JSON.parse(sessionStorage.getItem("M400Tags"));
   M500Tags = JSON.parse(sessionStorage.getItem("M500Tags"));
   M600Tags = JSON.parse(sessionStorage.getItem("M600Tags"));

   finalHangUpPercent = JSON.parse(sessionStorage.getItem("finalHangUpPercent"));
   finalM200percent = JSON.parse(sessionStorage.getItem("finalM200percent"));
   finalM300percent = JSON.parse(sessionStorage.getItem("finalM300percent"));
   finalM400percent = JSON.parse(sessionStorage.getItem("finalM400percent"));
   finalM500percent = JSON.parse(sessionStorage.getItem("finalM500percent"));
   finalM600percent = JSON.parse(sessionStorage.getItem("finalM600percent"));

   xaxisData = JSON.parse(sessionStorage.getItem("xaxisData"));
   percent = JSON.parse(sessionStorage.getItem("percent"));
   eachDay_escalatedCount = JSON.parse(sessionStorage.getItem("eachDay_escalatedCount"));
   newQueries_dates = JSON.parse(sessionStorage.getItem("newQueries_dates"));
               
   var csvFileData = [
       ['*********** RIBBON DATA ************'],
       ['Total Calls Count',totalCallsIntent],
       ['Total Queries',totalQueries],
       ['Flight Status',flight_status],
       ['Refund',refundTagsCount],

       ['\n********** USER JOURNEY *********\n'],
       ['Total Queries',M100sCount],
       ['In Scope Queries',inScopeQueries],
       ['Unassisted Automation',M200sCount],
       ['Flight Status',M201Count],
       ['No Show Refund',M202Count],
       ['Voluntary Refund',M203Count],
       ['Involuntary Refund',M204Count],
       ['Assisted Automation',M300sCount],
       ['API Faillures',M301sCount],
       ['Business Validations',business_validation_Count],
       ['Mobile Number not Mapped to PNR',mobileNoNotMapped],
       ['Agent Requested by User',M150andM500sCount],
       ['During the Flow',M500sCount],
       ['After the Flow',M150Count],
       ['User Declined Confirmation',M600sCount],
       ['No Deflection',M400sCount],
       ['Not In Scope',M100sCount - inScopeQueries],

       ['Dates',newQueries_dates],
       ['\n************ IVR OUTCOMES - TOTAL CALLS vs LIVE AGENT TRANSFER ***********\n'],
       ['Total calls for each day',xaxisData],
       ['Live agent transfer for each day',eachDay_escalatedCount],

       ['\n************** JOURNEYS (FLIGHT STATUS vs REFUND) ************\n'],
       ['Number of Flight Status Queries',M101Tags],
       ['Complete Automation for Flight Status',M201Tags],
       ['Number of Refund Queries',sampleArray2],
       ['Complete Automation for Refund',sampleArray4],
      
       ['\n************************ IVR EXIT POINTS ***********************\n'],
       ['Unassisted Automation percentage ',finalM200percent],
       ['Assisted Automation percentage',finalM300percent],
       ['Bot Exception percentage',finalM400percent],
       ['User Requested Agent Transfer percentage',finalM500percent],
       ['User Drop at Confirmation percentage',finalM600percent],
       ['Hang Ups Percentage',finalHangUpPercent]
     ];
       var csv = 'Name - Values\n';
       csvFileData.forEach(function(row) {
               csv += row.join(',');
               csv += "\n";
       });
       var hiddenElement = document.createElement('a');
       hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
       hiddenElement.target = '_blank';
       hiddenElement.download = 'dashboard_analytics.csv';
       hiddenElement.click();
}

function downloadFirst() {
    const imageLink = document.createElement('a');
    const canvas = document.getElementById('myChart');
    imageLink.download = 'ivr_outcomes.png';
    imageLink.href = canvas.toDataURL('image/png',1);
    imageLink.click();
}
function downloadSecond() {
    const imageLink = document.createElement('a');
    const canvas = document.getElementById('Chart2');
    imageLink.download = 'flightStatusVsRefund.png';
    imageLink.href = canvas.toDataURL('image/png',1);
    imageLink.click();
}
function downloadThird() {
    const imageLink = document.createElement('a');
    const canvas = document.getElementById('myChart4');
    imageLink.download = 'ivr_exit_points.png';
    imageLink.href = canvas.toDataURL('image/png',1);
    imageLink.click();
}
function PrintDiv() {
      var container = document.getElementById("basic-example");
      html2canvas(container, { allowTaint: true }).then(function (canvas) {
          var link = document.createElement("a");
          document.body.appendChild(link);
          link.download = "fourthGraph.jpg";
          link.href = canvas.toDataURL();
          link.target = '_blank';
          link.click();
      });
  }
function addClassToImage(element) {
var innerImage = document.getElementById('basic-example');
if(innerImage) {
  if(innerImage.classList.contains('magnify')) {
  innerImage.classList.remove('magnify');
  }
  else {
    innerImage.classList.add('magnify');
  }
}
}

//Chart 1
let graphNode1 = document.getElementById("graph-col-1")
            graphNode1.addEventListener("mouseover", (e)=>{
              let btn = document.querySelectorAll(".downloadOne")
              btn.forEach(i=>i.style.display = "block")
            }, false);
            graphNode1.addEventListener("mouseout", ()=>{
              let btn = document.querySelectorAll(".downloadOne")
            btn.forEach(i=>i.style.display = "none")
            }, false);
//Chart 2
let graphNode2 = document.getElementById("graph-col-2")
            graphNode2.addEventListener("mouseover", (e)=>{
              let btn = document.querySelectorAll(".downloadTwo")
              btn.forEach(i=>i.style.display = "block")
            }, false);
            graphNode2.addEventListener("mouseout", ()=>{
              let btn = document.querySelectorAll(".downloadTwo")
            btn.forEach(i=>i.style.display = "none")
            }, false);
//Chart 3
let graphNode3 = document.getElementById("graph-col-3")
            graphNode3.addEventListener("mouseover", (e)=>{
              let btn = document.querySelectorAll(".downloadThree")
              btn.forEach(i=>i.style.display = "block")
            }, false);
            graphNode3.addEventListener("mouseout", ()=>{
              let btn = document.querySelectorAll(".downloadThree")
            btn.forEach(i=>i.style.display = "none")
            }, false);
//Chart 4
            let graphNode = document.getElementById("graph-col-4")
            graphNode.addEventListener("mouseover", (e)=>{
              let btn = document.querySelectorAll(".downloadButton")
              btn.forEach(i=>i.style.display = "block")
            }, false);
            graphNode.addEventListener("mouseout", ()=>{
              let btn = document.querySelectorAll(".downloadButton")
            btn.forEach(i=>i.style.display = "none")
            }, false);